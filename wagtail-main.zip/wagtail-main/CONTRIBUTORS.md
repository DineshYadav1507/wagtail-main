## Core team

* Andy Chosak (consumerfinance.gov)
* Coen van der Kamp (Four Digits)
* Cynthia Kiser (Caltech)
* Dan Braghis (Torchbox)
* Dawn Wages (The Wharton School)
* Jacob Topp-Mugglestone (Torchbox)
* Kalob Taulien
* LB Johnston
* Loïc Teixeira (Springload)
* Matthew Westcott (Torchbox)
* Meagen Voss (Torchbox)
* Naomi Morduch Toubman
* Sævar Öfjörð Magnússon (Overcast)
* Sage Abdullah (Torchbox)
* Scott Cranfill (JPL)
* Stefan Hammer (wunderweiss)
* Storm Heg
* Thibaud Colas (Torchbox)
* Tim Allen (The Wharton School)
* Tom Dyson (Torchbox)
* Vince Salvino (CodeRed)

## Core team alumni

* Andy Babic
* Bertrand Bordage
* Codie Roelf
* Emily Horsman
* Janneke Janssen
* Jonny Scholes
* Josh Barr
* Karl Hobley
* Lisa Adams
* Martin Sandström
* Michael van Tellingen
* Mikalai Radchuk
* Mike Dingjan
* Rob Moorman
* Tim Heap
* Will Barton

## Contributors

* David Cranwell
* Helen Chapman
* Balazs Endresz
* Neal Todd
* Paul Hallett
* Serafeim Papastefanos
* Łukasz Bołdys
* peterarenot
* Levi Gross
* Delgermurun Purevkhuu
* Lewis Cowper
* Stephen Newey
* Ryan Foster
* v1kku
* Miguel Vieira
* Ben Emery
* David Smith
* Ben Margolis
* Tom Talbot
* Jeffrey Hearn
* Robert Clark
* Nathan Brizendine
* Gordon Pendleton
* John-Scott Atlakson
* Eric Drechsel
* Alejandro Giacometti
* Robert Rollins
* linibou
* Timo Rieber
* Jerel Unruh
* georgewhewell
* Frank Wiles
* Sebastian Spiegel
* Alejandro Varas
* Martin Sanders
* Benoît Bar
* Claudemiro
* Tiago Henriques
* Arne Schauf
* Jordi Joan
* Damian Moore
* signalkraft
* Mac Chapman
* Brett Grace
* Nar Chhantyal
* Michael Fillier
* Mitchel Cabuloy
* Piet Delport
* Tom Christie
* Michael van Tellingen
* Scot Hacker
* Kyungil Choi
* Joss Ingram
* Christoph Lipp
* Michael Cordover
* Timothy Allen
* Rob Shelton
* Anurag Sharma
* Maximilian Stauss
* Salvador Faria
* Alex Gleason
* Ryan Pineo
* Petr Vacha
* Sævar Öfjörð Magnússon
* Ashia Zawaduk
* Denis Voskvitsov
* Kyle Stratis
* Sergey Nikitin
* John Draper
* Rich Brennan
* Alex Bridge
* Tamriel
* LKozlowski
* Matthew Downey
* Maris Serzans
* Shu Ishida
* Ben Kerle
* Christian Peters
* Adon Metcalfe
* rayrayndwiga
* Rich Atkinson
* jnns
* Eugene MechanisM
* Benjamin Bach
* Alexander Bogushov
* Aarni Koskela
* alexpilot11
* Peter Quade
* Josh Hurd
* Matt Fozard
* Chris Rogers
* Josh Schneier
* Charlie Choiniere
* Nigel Fletton
* Kait Crawford
* Adam Bolfik
* Thomas Winter
* Gareth Price
* Liam Brenner
* Nicolas Kuttler
* Juha Kujala
* Eirik Krogstad
* Rob Moorman
* Matthijs Melissen
* Jonas Lergell
* Danielle Madeley
* Roel Bruggink
* Yannick Chabbert
* Tomas Olander
* Andrew Tork Baker
* Vincent Audebert
* Jack Paine
* Nick Smith
* João Luiz Lorencetti
* Jason Morrison
* Mario César
* Moritz Pfeiffer
* David Seddon
* Brad Busenius
* Juha Yrjölä
* Bojan Mihelac
* Robert Moggach
* Stephen Rice
* Behzad Nategh
* Yann Fouillat (Gagaro)
* Richard McMillan
* Johannes Spielmann
* Franklin Kingma
* Ludolf Takens
* Oktay Altay
* Paul J Stevens
* kakulukia
* Raphael Stolt
* Tim Graham
* Tobias Schmidt
* Chris Darko
* Aymeric Augustin
* Adriaan Tijsseling
* sebworks
* Sean Muck
* Fábio Macêdo Mendes
* Eraldo Energy
* Jesse Legg
* Tim Leguijt
* Luiz Boaretto
* Jonathon Moore
* Kees Hink
* Jayden Smith
* emg36
* Stein Strindhaug
* Žan Anderle
* Mattias Loverot
* Ricky Robinett
* Axel Haustant
* Henk-Jan van Hasselaar
* alexfromvl
* Jaap Roes
* Ducky
* Shawn Makinson
* Tom Miller
* Luca Perico
* Gary Krige
* Hammy Goonan
* Thejaswi Puthraya
* Benoît Vogel
* Manuel E. Gutierrez
* Albert O'Connor
* Morgan Aubert
* Diederik van der Boor
* Sean Hoefler
* Edd Baldry
* PyMan Claudio Marinozzi
* Jeffrey Chau
* Craig Loftus
* MattRijk
* Marco Fucci
* Mihail Russu
* Robert Slotboom
* Erick M'bwana
* Andreas Nüßlein
* John Heasly
* Nikolai Røed Kristiansen
* Alex Zagorodniuk
* glassresistor
* Mikael Svensson
* Peter Baumgartner
* Matheus Bratfisch
* Kevin Whinnery
* Martey Dodoo
* David Ray
* Alasdair Nicol
* Tobias McNulty
* Vorlif
* Kjartan Sverrisson
* Christine Ho
* Trent Holliday
* jacoor
* hdnpl
* Tom Hendrikx
* Ralph Jacobs
* Wietze Helmantel
* Patrick Gerken
* Will Giddens
* Maarten Kling
* Huub Bouma
* Thijs Kramer
* Ramon de Jezus
* Ross Curzon-Butler
* Daniel Chimeno
* Medhat Assaad
* Sebastian Bauer
* Martin Hill
* Maurice Bartnig
* Eirikur Ingi Magnusson
* Harris Lapiroff
* Hugo van den Berg
* Olly Willans
* Ben Enright
* Alice Rose
* John Franey
* Marc Tudurí
* Lucas Moeskops
* Rob van der Linde
* Paul Kamp
* David Wasylciw
* Eugene Morozov
* Levi Adler
* Edwar Baron
* Tomasz Knapik
* Venelin Stoykov
* Emily Horsman
* jcronyn
* Ben Sturmfels
* Anselm Bradford
* Mads Jensen
* Samir Shah
* Patrick Woods
* Ross Crawford-d'Heureuse
* rifuso
* Jon Carmack
* Martin Sandström
* Adrian Turjak
* Michael Palmer
* Philipp Bosch
* misraX
* Bruno Alla
* Christopher Bledsoe (The Motley Fool)
* Florent Osmont
* J Rob Gant
* Mary Kate Fain
* Dário Marcelino
* Dave Bell
* Ben Weatherman
* Carlo Ascani
* Julian Gallo
* Dan Dietz
* Michael Harrison
* Todd Dembrey
* Sebastian Brestin
* Casper Timmers
* Kevin Chung (chungky)
* Kim Chee Leong
* Dan Swain
* Alexs Mathilda
* Tony Yates
* Pomax
* Arthur Holzner
* Alejandro Garza
* Rajeev J Sebastian
* Sander Tuit
* Tim Kamanin
* Sergey Fedoseev
* Harm Zeinstra
* David Moore
* Pierre Geier
* Jérôme Lebleu
* Victor Miti
* Andrew Plummer
* Dmitry Vasilev
* Benjamin Thurm
* Ed Henderson
* Strother Scott
* Daniele Procida
* Catherine Farman
* Abdulmalik Abdulwahab
* Andrew Crewdson
* Aram Dulyan
* Kevin Howbrook
* Ryan Verner
* Oliver Wilkerson
* Matthew Schinckel
* Michael Borisov
* Dan Braghis
* Ben Dickinson
* Meteor0id
* Naa Marteki Reed
* Jorge Barata
* Brady Moe
* Yi Huang
* Stas Rudakou
* Abdulaziz Alfuhigi
* Dzianis Sheka
* Scott Cranfill
* gmmoraes
* Justin Focus
* Fedor Selitsky
* Seb Brown
* Noah B Johnson
* Hillary Jeffrey
* Nick Travis
* Maylon Pedroso
* Thijs Walcarius
* mukesh5
* frmdstryr
* Aidarbek Suleimenov
* Matthew Linares
* Asanka Lihiniyagoda
* David Beitey
* Paul Vetch
* Vladimir Knobel
* Matt Collins
* Thomas Elliott
* damianosSemmle
* Evan Winter
* Neil Lyons
* Gassan Gousseinov
* Thomas Kremmel
* patta42
* Esper Kuijs
* Damian Grinwis
* Wesley van Lee
* Md Arifin Ibne Matin
* Tom Usher
* Haydn Greatnews
* Katie Locke
* Cassidy Brooke
* dthompson86
* Jason Dilworth
* Deniz Dogan
* Po-Chuan Hsieh
* scil
* Mike Hearn
* Samuel Mendes
* Adam Eikman
* Andreas Bernacca
* Alex Tomkins
* Beth Menzies
* Michael Bunsen
* Dillen Meijboom
* George Hickman
* Eric Dyken
* Jordan Bauer
* Fidel Ramos
* Quadric
* jonny5532
* William Blackie
* Andrew Miller
* Rodrigo
* Iman Syed
* John Carter
* Jonathan Liuti
* Rahmi Pruitt
* Sanyam Khurana
* Pavel Denisov
* Mikael Engström
* Zac Connelly
* Sarath Kumar Somana
* Dani Hodovic
* Janne Alatalo
* Colin Klein
* Eduard Luca
* Kiril Staikov
* Saptak Sengupta
* Dawid Bugajewski
* Brian Whitton
* Tim White
* Mike Janger
* Prithvi MK
* pySilver
* a-mere-peasant
* David T Thompson
* kailwallin
* ryanomor
* Thijs Baaijen
* Stefani Castellanos
* Aliosha Padovani
* Tom Readings
* Andrey Smirnov
* Tim Gates
* Timothy Bautista
* Pete Andrew
* Benedikt Willi
* Johannes Vogel
* Sam Costigan
* Eric Sherman
* Martin Coote
* Simon Evans
* Arkadiusz Michał Ryś
* James O'Toole
* Storm Heg
* Daniel (aritas1)
* timmysmalls
* dtwm
* Steve Lyall
* Lars van de Kerkhof
* pimarc
* minusf
* Paulo Alvarado
* Karran Besen
* Mohamed Feddad
* Michał (Quadric) Sieradzki
* Vlad Gerasimenko
* Tomonori Tanabe
* Jannik Wempe
* Sylvain Fankhauser
* Ascani Carlo
* Chris Ranjana
* Tomas Walch
* François Poulain
* Jim Jazwiecki
* Kim LaRocca
* Jonatas Baldin
* Rick van Hattem
* Luke Hardwick
* Saeed Tahmasebi
* Liam Mullens
* Caitlin White
* Brylie Christopher Oxley
* Lacey Williams Henschel
* Dan Bentley
* GTpyro
* Yngve Høiseth
* Andrew Bunker
* Nikolay Lukyanov (mozgsml)
* Jean Zombie
* Pascal Widdershoven
* Max Gabrielsson
* Steven Wood
* Gabriel Peracio
* Jesse Menn
* Robbie Mackay
* Vyacheslav Matyukhin
* Vince Salvino
* Dino Perovic
* Ameet Virdee
* Anton Zhyltsou (@samgans)
* Meghana Bhange
* Cole Maclean
* Noah H
* David Bramwell
* Naglis Jonaitis
* Luis Nell
* Alex Sa
* Andreas Morgenstern
* Kristin Riebe
* Vadim Karpenko
* Bohreromir
* Fernando Cordeiro
* Matthias Rohmer
* Joshua Marantz
* Mike Brown
* Helder Correia
* James Gutu
* John Esther
* Lara Thompson
* Tibor Leupold
* Joan Eliot
* Sagar Agarwal
* Susan Dreher
* Dale Evans
* Vlad Podgurschi
* Kevin Breen
* Ihor Marhitych
* Andre Fonseca
* Tidiane Dia
* Jan Seifert
* hardcodd
* Chris Pollard
* Godswill Melford
* Jake Howard
* Petr Dlouhý
* Andrew Stone
* Daniel Fairhead
* Kevin Gutiérrez
* Brandon Murch
* Sean Kelly
* Himesh Samarasekera
* Jannis Vajen
* Dmitrii Faiazov
* Amy Chan
* Chakita Muttaraju
* Fabien Le Frapper
* Jonathan "Yoni" Knoll
* Onkar Apte
* Justin Slay
* Desai Akshata
* Krzysztof Jeziorny
* Nick Moreton
* Bryan Williams
* Wout De Puysseleir
* Kamil Marut
* Jane Liu
* Joe Howard
* Jochen Wersdörfer
* Sakshi Uppoor
* Indresh P
* Rinish Sam
* Anirudh V S
* Shariq Jamil
* Kyle Bayliss
* John Simms
* Justin Michalicek
* Nabil Khalil
* Md. Fahim Bin Amin
* Michael Karamuth
* Vu Pham
* Khanh Hoang
* Jason Attwood
* Vladimir Tananko
* Rizwan Mansuri
* Dennis McGregor
* Joshua Munn
* Gianluca De Cola
* Paarth Agarwal
* Nicolas Ferrari
* Vibhakar Solanki
* Riley de Mestre
* Mariusz Felisiak
* Dharmik Gangani
* Kyle Hart
* Stephanie Cheng Smith
* Luis Espinoza
* Hitansh Shah
* Saurabh Kumar
* James Ray
* Anuja Verma
* Shrey Parekh
* Vinit Kumar
* Shwet Khatri
* Abdulmajeed Isa
* Sandil Ranasinghe
* Caio Jhonny
* Heather White
* Onno Timmerman
* Kyle J. Roux
* Vaibhav Shukla
* Rishank Kanaparti
* Daniel Kirkham
* Luz Paz
* Simon Krull
* Przemysław Buczkowski
* Josh Woodcock
* Christian Franke
* Tom Hu
* Thiago Costa de Souza
* Benedict Faw
* Lucie Le Frapper
* Jaspreet Singh
* Yves Serrano
* Hugh Rawlinson
* Noble Mittal
* Oliver Parker
* Viggo de Vries
* Yuekui
* Igor Strapko
* Sandeep M A
* Bernd de Ridder
* Stefano Silvestri
* Alexander Rogovskyy
* Dominik Lech
* Paritosh Kabra
* Akash Kumar Sen
* Xabier Bello
* Mehrdad Moradizadeh
* ariadi
* Thomas van der Hoeven
* Kurt Wall
* Adam Johnson
* Josh Thomas
* Christophe Bastin
* Nicholas Johnson
* Shohan Dutta Roy
* Alex (sashashura)
* Adinapunyo Banerjee
* Dan Hayden
* Jadesola Kareem
* Dauda Yusuf
* Damilola Oladele
* Albina Starykova
* Sam Moran
* Toyibat Adele
* Umar Farouk Yunusa
* Chizoba Nweke
* Seremba Patrick
* Ruqouyyah Muhammad
* Loveth Omokaro
* Abayomi Victory
* Victoria Poromon
* Darrel O'Pry
* Mary Ayobami
* Bolarinwa Comfort Ajayi
* Mary Ojo
* Oluwaloseyi Adeleye
* Dennis Onyeka
* Precious Arinda
* Ogunbanjo Oluwadamilare
* Damee Zivah Olawuyi
* Harry Percival
* Akua Dokua Asiedu
* Chisom Okeoma
* Marvis Chukwudi
* Jordan Rob
* Juliet Adeboye
* Yekasumah
* Theresa Okoro
* Omerzahid Ali
* Aman Pandey
* Doug Harris
* Mohammad Areeb
* Florian Vogt
* Fatuma Abdullahi
* Elizabeth Bassey
* Suyash Singh
* Temidayo Azeez
* Mark McOsker
* Benita Anawonah
* Anisha Singh
* Ivy Jeptoo
* Jeremy Thompson
* Ben Gosney
* damascene
* Natarajan Balaji
* Vallabh Tiwari
* dr-rompecabezas
* Rishabh jain
* Jhonatan Lopes
* Alex Simpson
* GLEF1X
* Nick Lee
* Beniamin Bucur
* Ananjan-R
* Yosr Karoui
* Aadi jindal
* Satvik Vashisht
* Rishabh Kumar Bahukhandi
* Ayman Makroo
* Suyash Srivastava
* Julian Bigler
* Kenny Wolf
* Himanshu Garg
* Christopher Wardle
* Jatin Kumar
* Hans Kelson
* Sam
* Deepam Priyadarshi
* Mng
* George Sakkis
* Mehul Aggarwal
* Babitha Kumari
* Mansi Gundre
* Hanoon
* Steve Steinwand
* Swojak-A
* fidoriel
* Ramon Wenger
* Christer Jensen
* Virag Jain
* Lukas von Allmen
* Ester Beltrami
* Justin Koestinger
* NikilTn
* Thiago C. S. Tioma
* Kevin Chung (kev-odin)
* valnuro
* Vitaly Babiy
* Sébastien Corbin
* Sahil Jangra
* Henry Harutyunyan
* Alex Morega
* Scott Foster
* Florent Lebreton
* Shreshth Srivastava
* Sandeep Choudhary
* Antoni Martyniuk
* Gareth Palmer
* Hatim Makki Hoho
* Hussain Saherwala
* Faishal Manzar
* Rohit Sharma
* Subhajit Ghosh
* Neeraj Yetheendran
* TopDevPros
* Sandra Ashipala
* Omkar Jadhav
* Charlie Sue
* Dhrűv
* Sandro Rodrigues
* Brian Mugo
* Panagiotis H.M. Issaris
* Damilola Oladele
* Olumide Micheal
* Chiemezuo Akujobi
* Krish Soni
* Chris Shaw
* claudobahn
* Florian Delizy
* Susheel Thapa
* Hazh. M. Adam
* Chris Lawton
* Meghana Reddy
* Chinedu Ihedioha
* scott-8
* phijma-leukeleu
* CheesyPhoenix
* Vedant Pandey
* Ian Price
* Elhussein Almasri
* Marcel Kornblum
* Cameron Lamb
* Sam Dudley
* Varun Kumar
* Andrey Nehaychik
* Meli Imelda
* Kehinde Bobade
* Joe Tsoi
* Cassidy Pittman
* Gunnar Scherf
* Mariana Bedran Lesche
* Bhuvnesh Sharma
* Ben Morse
* Shlomo Markowitz
* Felipe Lobato
* Nandini Arora
* Sai Srikar Dumpeti

## Translators

* Afrikaans: Jaco du Plessis, Jared Osborn
* Arabic: Bashar Al-Abdulhadi, Abdulaziz Alfuhigi, Roger Allen, Khaled Arnaout, Amr Awad, Mohammed Abdul Gadir, Mohamed HossamElDin, Ahmad Kiswani, Waseem Kntar, Mahmoud Marayef, Mohamed Mayla, Ahmed Miske Sidi Med, Younes Oumakhou, Ultraify Media
* Armenian: Vachagan
* Azerbaijani: Mirza Iskandarov
* Bangla: Mahmud Abdur Rahman
* Basque: Unai Zalakain
* Belarusian: Stas Rudakou, Andrei Satsevich, Tatsiana Tsygan
* Bulgarian: Lyuboslav Petrov
* Burmese: ime11
* Catalan: Antoni Aloy, David Llop, Roger Pons
* Chinese: hanfeng, Lihan Li, Leway Colin, Adeline Link, Orangle Liu, shengsheng gz
* Chinese (Simplified): Ed, Yin Guanhao, hanfeng, Fan Hei, Yi Huang, Daniel Hwang, Jian Li, Monty Ng, Terry Peng, Aosp T, Listeng Teng, Feng Wang, whuim, Favo Yang, Fred Zeng, Joey Zhao, Vincent Zhao, zhushajun
* Chinese (Traditional): gogobook, Andy Kong, Lihan Li, Ocin Leung, Jp Shieh, Chih Wang, Brian Xu, Yeh Yen-Ke, Yu Hsun Lee
* Croatian (Croatia): Dino Aljević, Marko Burazin, Ivica Dosen, Luka Matijević
* Czech: Ales Dvorak, Jan Feřtek, Martin Galda, IT Management, Tomáš Jeřábek, Vláďa Macek, Eva Mikesova, Mořeplavec, Sophy O, Martina Oleksakova, Kryštof Pilnáček, Tomáš Podivínský, Ivan Pomykacz, Jiri Stepanek, Marek Turnovec, Mirek Zvolský
* Danish: Benjamin Bach, Mads Kronborg, MRostgaard, Asger Sørensen
* Dutch: benny_AT_it_digin.com, Bram, Ramon de Jezus Brecht Dervaux, Harmen, Storm Heg, Kees Hink, Huib Keemink, Franklin Kingma, Maarten Kling, Thijs Kramer, Samuel Leeuwenburg, mahulst, Meteor0id, Rob Moorman, Benjamin van Renterghem, Michael van Tellingen, Arne Turpyn, Coen van der Kamp
* English (India): Neeraj PY, Apoorv Saini
* Estonian: Erlend Eelmets, Martin, Ragnar Rebase
* Finnish: Jiri Grönroos, Eetu Häivälä, Niklas Jerva, Aarni Koskela, Rauli Laine, Valter Maasalo, Glen Somerville, Juha Yrjölä
* French: Adrien, Timothy Allen, Sebastien Andrivet, Bertrand Bordage, André Bouatchidzé, Sébastien Corbin, Aurélien Debord, Romain Dorgueil, Tom Dyson, Antonin Enfrun, Axel Haustant, Renaud Kern, Fabien Le Frapper, Léo, Pierre Marfoure, nahuel, Sophy O, Dominique Peretti, fpoulain, Loïc Teixeira, Benoît Vogel
* Galician: X Bello, Amós Oviedo
* Georgian: André Bouatchidzé
* German: Ettore Atalan, Bohreromir, Matti Borchers, Benedikt Breinbauer, Donald Buczek, Patrick Craston, Peter Dreuw, Oliver Engel, Stefan Hammer, Patrick Hebner, Krzysztof Jeziorny, Benjamin Kaspar, Henrik Kröger, Tibor L, Tammo van Lessen, Martin Löhle, Wasilis Mandratzis-Walz, Daniel Manser, Matthias Martin, m0rph3u5, Max Pfeiffer, Moritz Pfeiffer, Herbert Poul, Karl Sander, Tobias Schmidt, Scriptim, Johannes Spielmann, Raphael Stolt, Benjamin Thurm, Norman Uekermann, unicode_it, Jannis Vajen, Florian Vogt, Alexander Weiß, Matthew Westcott, Benedikt Willi
* Greek: Jim Dal, Dimitri Fekas, fekioh, George Giannoulopoulos, Yiannis Inglessis, Wasilis Mandratzis-Walz, Nick Mavrakis, NeotheOne, Serafeim Papastefanos
* Haitian: Hantz Vius
* Hebrew (Israel): Lior Abazon, bjesus, Yossi Lalum, Gilad Levi, Men770, Adi Ron, Oleg Sverdlov
* Hindi: Apoorv Saini
* Hungarian: Istvan Farkas, Laszlo Molnar, Kornél Novák Mergulhão, BN, Patrik Radics, Aron Santa
* Icelandic (Iceland): Arnar Tumi Þorsteinsson, Kjartan Sverrisson, Sævar Öfjörð Magnússon
* Indonesian (Indonesia): atmosuwiryo, Sutrisno Efendi, Dzikri Hakim, Reshi Mahendra, Geek Pantura, Andry Widya Putra, Ronggo Radityo, M. Febrian Ramadhana
* Italian: Sandro Badalamenti, Marco Badan, Edd Baldry, Claudio Bantaloukas, Guglielmo Celata, Gian-Maria Daffre, gcm, Giacomo Ghizzani, LB (Ben Johnston), Marco Lerco, Stefano Marchetto, Carlo Miron, Alessio Di Stasio, Andrea Tagliazucchi
* Japanese: Sangmin Ahn, Goto Hayato, Shuhei Hirota, Shu Ishida, bayside kent, Yudai Kobayashi, Tri Minh, Koji Miyazawa, Tetsuya Morimoto, Tomo Mizoe, Hideaki Oguchi, Safu9, Hiroki Sawano, Kinoshita Shinji, Daigo Shitara, Okosama Star, Shimizu Taku, umepon0626, Takuya Yamamoto
* Korean: Kyungil Choi, Jihan Chung
* Latvian: Aleksandrs Korņijenko, Reinis Rozenbergs, Maris Serzans
* Lithuanian: Matas Dailyda, Naglis Jonaitis
* Maori: Awatea Randall
* Mongolian: Myagmarjav Enkhbileg, Delgermurun Purevkhuu, Soft Exim, visual
* Norwegian Bokmål: Eirik Krogstad, Ole Kristian Losvik, Robin Skahjem-Eriksen, Stein Strindhaug
* Persian: Vessal Daneshvar, Mohsen Hassani, Mostafa Heidarian, Ehsan Jahanbakhsh, Mohammad reza Jelveh, Amir Mahmoodi, Mehdi, Mohammad Hossein Mojtahedi, Hamed Najand, Mohammad Sharif Shokouhi, Salar Yazdani, Py Zenberg
* Polish: X Bello, Łukasz Bołdys, Krzysztof Jeziorny, Konrad Lalik, Dominik Lech, Miron Levitsky, Mateusz, Miłosz Miśkiewicz, Piotr Moskal, Kacper Podpora, Bartek Sielicki, Grzegorz Wasilewski, Bartosz Wiśniewski
* Portuguese (Brazil): Claudemiro Alves Feitosa Neto, Bruno Bertoldi, Luiz Boaretto, Éder Brito, Gladson Brito, Thiago Cangussu, Daniel Carvalho, Hernandison Da Silva Bispo, Vitor Hugo da Silva Lima, Gustavo Simões, Rodrigo de Almeida Sottomaior Macedo, Gilson Filho, Joao Garcia, Felipe Lobato, João Luiz Lorencetti, A M, Iuri L. Machado, Marcio Mazza, Douglas Miranda, Guilherme Nabanete, Fabio Santos, Ed Wurch
* Portuguese (Portugal): Gladson Brito, Hugo Cachitas, Thiago Cangussu, Luís Tiago Favas, Diogo Gomes, Tiago Henriques, Felipe Lobato, Jose Lourenco, Rui Martins, Nuno Matos, Douglas Miranda, Diogo Ribeiro, Diogo Silva, Manuela Silva
* Romanian: Dan Braghis, Julian C, Bogdan Mateescu, Alex Morega
* Russian: ajk, Anatoly, Andrey Avdey, Paul Bid, Vitaly Chekryzhev, Daniil, Mikhail Gerasimov, gsstver, sergeybe, Sergey Khalymon, Sergey Komarov, Dmitry Kostelyanets, Miron Levitskiy, Arseni M, Sergey Mazanov, Eugene MechanisM, Rustam Mirzaev, Zhdan Parfenov, Alexander Penshin, Mikalai Radchuk, Alexandr Romantsov, Andrei Satsevich, Mikhail Sidorov, Alexey Sveshnikov, Nikita Tonkoshkur, Alexey Trofimov, Tatsiana Tsygan, Viktor, Nikita Viktorovich, Vassiliy Vorobyov, Vlad
* Serbian: Nikola Kadić
* Slovak (Slovakia): Stevo Backor, dellax, Jozef Gáborík, Martin Janšto, Jozef Karabelly
* Slovenian: Andrej Marsetič, Mitja Pagon, Lev Predan Kowarski, Urban Prevc, Matej Stavanja
* Spanish: Antoni Aloy, Mauricio Baeza, Lautaro Bringas, Daniel Chimeno, Oscar Luciano Espirilla Flores, fonso, Hector Garcia, José Luis, Florian Merges, Oluwadamilare Ogunbanjo, Amós Oviedo, Maylon Pedroso, Enrique Sánchez-Reboto García, Joaquín Tita, Daniel Wohlgemuth, Rodrigo Yanez, Unai Zalakain
* Swedish: Philip Andersen, Andreas Bergström, Jim Brouzoulis, Oscar Fröberg, Alexander Holmbäck, Elias Johnstone, André Karlsson, Jon Karlsson, Ludwig Kjellström, Thomas Kunambi, Andreas Lans, Hannes Lohmander, Martin Sandström, Tomas Walch
* Tamil: Ramakrishnan Sathyanarayanan
* Tetum: Alessandro, Joanico Barros, Peter Coward, Mariano de Deus, Onorio de Jesus Afonso, Mario Alves Pinto
* Thai: Amawalee Combe, Jon Combe, Walaksawan Vervoort
* Turkish: Saadettin Yasir Akel, Umut Bektaş, Halit Çelik, Zafer Cengiz, Cihad Gündoǧdu, Basitlik İyidir, Fatih Koç koç, José Luis, Py Data, Ahmet Sarıcan, Halim Turan, Ragıp Ünal, Suayip Uzulmez
* Turkish (Turkey): Saadettin Yasir Akel, Basitlik İyidir, Umut Bektaş, Aydın Zafer Cengiz, lzm dgl, Cihad Gündoǧdu, Ahmet Serdar Karadeniz, Fatih Koç koç, José Luis, Py Data, Halim Turan, Ragıp Ünal
* Ukrainian: Yuri Fabirovsky, Vladislav Herasimenko, Mikolai Incognito, Anastasiia La, Sergiy Shkodenko, Viktor Shytiuk, Ivan Tyshchenko, Zoriana Zaiats, Mykola Zamkovoi
* Vietnamese: Amelia Dao, Duc Huynh, Hồng Quân Nguyễn, Luan Nguyen, Vu Pham
* Welsh: Philip Crisp, Adam Hughes
