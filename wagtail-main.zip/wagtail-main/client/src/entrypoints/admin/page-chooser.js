import { PageChooser } from '../../components/ChooserWidget/PageChooserWidget';

window.PageChooser = PageChooser;
