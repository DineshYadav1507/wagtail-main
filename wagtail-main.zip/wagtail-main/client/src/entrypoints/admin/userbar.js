import { Userbar } from '../../includes/userbar';

customElements.define('wagtail-userbar', Userbar);
