import { DocumentChooser } from '../../components/ChooserWidget/DocumentChooserWidget';

window.DocumentChooser = DocumentChooser;
