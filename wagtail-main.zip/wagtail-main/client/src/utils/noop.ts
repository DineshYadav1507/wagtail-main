/**
 * This method does nothing, returns `undefined`.
 */
const noop = (): void => {};

export { noop };
